package com.cg.bank.exception;

@SuppressWarnings("serial")
public class BankException extends Exception {

	public BankException(String message) {
		super(message);
	}

}
