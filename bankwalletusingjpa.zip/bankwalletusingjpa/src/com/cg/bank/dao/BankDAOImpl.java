package com.cg.bank.dao;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.bank.dto.Customer;
import com.cg.bank.exception.AmountException;
import com.cg.bank.exception.BankException;



public class BankDAOImpl implements BankDAO{
	
	EntityManager manager;
	public BankDAOImpl() {
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("JPA-PU");
				manager = emf.createEntityManager();
			
		// TODO Auto-generated constructor stub
	}

	@Override
	public Customer createAccount(Customer c) {
		manager.getTransaction().begin();
		manager.persist(c);
		manager.getTransaction().commit();
		// TODO Auto-generated method stub
		return c;
	}

	@Override
	public double showBalance(String mobileno) {
		manager.getTransaction().begin();
		Customer c=manager.find(Customer.class,mobileno);
		double bal=c.getAmount();
		return bal;

	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			double amount) throws  AmountException  {
		manager.getTransaction().begin();
		Customer c=manager.find(Customer.class, sourceMobileNo);
				double d=c.getAmount();
		Customer c1=manager.find(Customer.class, targetMobileNo);
				double e=c.getAmount();// TODO Auto-generated method stub
				if(d>amount){
					d=d-amount;
					e=e+amount;
					c.setAmount(d);
					c1.setAmount(e);
					System.out.println("Transfer of Rs: "+amount+"from"+sourceMobileNo+"to"+targetMobileNo+"is successful");
					
				}
				else throw new AmountException();
				manager.getTransaction().commit();
				return c;
		
	}

	@Override
	public Customer depositAmount(String mobileNo, double amount) {
		
		  manager.getTransaction().begin();
	        Customer cust = manager.find(Customer.class, mobileNo);
	        double amt =cust.getAmount();
	        amt=amt+amount;
	        System.out.println("New Updated Balance : "+amt);
	        cust.setAmount(amount);;
	        manager.getTransaction().commit();
		// TODO Auto-generated method stub
		return cust;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, double amount)
			 {
		   manager.getTransaction().begin();
	        Customer cust = manager.find(Customer.class, mobileNo);
	        double amt =cust.getAmount();
	        amt=amt-amount;
	        System.out.println("Updated Balance : "+amt);
	        cust.setAmount(amount);
	        manager.getTransaction().commit();
		return cust;
	}

	@Override
	public Customer getAccount(String sourceMobileNo) {
		Customer cust = manager.find(Customer.class, sourceMobileNo);
		return cust;
	}

	@Override
	public boolean setAccount(String targetMobileNo, double d) {
		Customer cust = getAccount(targetMobileNo);
		cust.setAmount(d);
		manager.merge(cust);
		return true;
	}
	
}