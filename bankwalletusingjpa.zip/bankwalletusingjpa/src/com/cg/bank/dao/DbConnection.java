package com.cg.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.bank.exception.BankException;

public class DbConnection {
	private static Connection con;
	public static Connection getConnection() throws BankException{
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "abdul";
		String pwd = "samim9874";
		
		try {
			if(con == null)
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  System.out.println("class loaded...");
			  con = DriverManager.getConnection(url,username,pwd);
			  System.out.println("connected to db .......");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BankException("Invalid Entry");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new BankException("unable to find a table");
		}
		return con;
			
	
	}	
	/*public static void main(String args[]) {
		try {
			getConnection();
		}
		catch (PurchaseException e) {
			e.printStackTrace();
		}
	}*/
	
}
